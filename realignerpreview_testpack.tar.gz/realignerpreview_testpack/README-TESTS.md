# RealignerPreview Test Pack

## Quick start
```bash
git clone https://github.com/RDM3DC/realignerpreview.git
cd realignerpreview
# drop 'tests/', 'pytest.ini', and 'requirements-dev.txt' from this pack into the repo root
pip install -r requirements-dev.txt
pytest -q
```
